/* Initialize the data in the DB */
import { pool } from './database.js';

const dropTables = async () => {
    try {
        
        await pool.query('DROP TABLE IF EXISTS reviews');
        await pool.query('DROP TABLE IF EXISTS restaurants');
        console.log("Dropped tables successfully.");
    } catch (error) {
        console.error("Error dropping tables:", error);
    }
};

const createTables = async () => {
    try {
        
        await pool.query(`
            CREATE TABLE IF NOT EXISTS restaurants (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100),
                phone VARCHAR(20),
                address VARCHAR(255),
                photo VARCHAR(255)
            );
        `);

        
        await pool.query(`
            CREATE TABLE IF NOT EXISTS reviews (
                id SERIAL PRIMARY KEY,
                rating INTEGER NOT NULL,
                content TEXT,
                restaurant_id INTEGER REFERENCES restaurants(id) ON DELETE CASCADE
            );
        `);

        console.log("Created tables successfully.");
    } catch (error) {
        console.error("Error creating tables:", error);
    }
};

const insertData = async () => {
    try {
       
        const restaurants = [
            { name: 'Restaurant A', phone: '123-456-7890', address: '123 Main St', photo: 'url1' },
            { name: 'Restaurant B', phone: '234-567-8901', address: '456 Elm St', photo: 'url2' }
        ];

        
        const restaurantIds = [];
        for (const { name, phone, address, photo } of restaurants) {
            const result = await pool.query(
                `INSERT INTO restaurants (name, phone, address, photo) VALUES ($1, $2, $3, $4) RETURNING id`,
                [name, phone, address, photo]
            );
            restaurantIds.push(result.rows[0].id);
        }

       
        const reviews = [
            { rating: 5, content: 'Great food!', restaurant_id: restaurantIds[0] },
            { rating: 4, content: 'Nice ambiance', restaurant_id: restaurantIds[0] },
            { rating: 3, content: 'Average experience', restaurant_id: restaurantIds[1] },
            { rating: 5, content: 'Excellent service!', restaurant_id: restaurantIds[1] }
        ];

        for (const { rating, content, restaurant_id } of reviews) {
            await pool.query(
                `INSERT INTO reviews (rating, content, restaurant_id) VALUES ($1, $2, $3)`,
                [rating, content, restaurant_id]
            );
        }

        console.log("Inserted initial data successfully.");
    } catch (error) {
        console.error("Error inserting data:", error);
    }
};

const setup = async () => {
    await dropTables();
    await createTables();
    await insertData();
    pool.end(); // 关闭连接池
    console.log("Database setup complete.");
};

setup();
